# Few-shot inference 16/11/2026

Checkpoint: component 176.500, SHA-256 `9b2e191b434f05cd2975dd9eec8f0acf9c8a9f103da051491f75f2bbcfb8a290`.

806 prompt × 3 support variants = 2418 PNG. All 12 inputs are retained plus 3 repeats to fill 15 slots. Seeds alter repeated references, not a learned stochastic style distribution. Single characters are generated as single-character queries. Multiword lines concatenate word outputs with 16px gaps. Synthetic probes are labelled explicitly.

Open [index.html](index.html) to filter by category, prompt and variant. Primary previews use clean_742. Compare raw_742 before attributing changes to the model. Background cleaning is deterministic blue-chroma extraction, not retraining or image synthesis. Native model emits grayscale at 32px height; previews enlarge it for inspection.

No human/OCR quality scores are claimed. Checkpoint selection is based on the previous fixed benchmark, not a guarantee of optimality for this external writer. Matching reference words are demonstrations, not held-out tests.

See run.json for all inputs/checksums, support composition, memory and runtime; prompts.json and samples.json contain the exact workload and outputs.

[Comparison overview](overview_comparison.png) · [Original references](references_original.png).

Reproduction command (run inside VATr-pp; choose a fresh output folder):

```sh
/home/giaphk/SpiS-GAN/.venv/bin/python scripts/infer_fewshot_gallery.py --style-folder /home/bachdx2/DraftAnything/few-shot --checkpoint runs/weights_upload_261114/component_176500_generator.pth --output runs/fewshot_external_NEW_OUTPUT
```
